package com.ftonyedemo.sqlite_demo_gr431432;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class MyBooksTableDataGateWay extends SQLiteOpenHelper {

    private  SQLiteDatabase db;

    public MyBooksTableDataGateWay(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists Books;");
        onCreate(sqLiteDatabase);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
         String myQuery = "create table if not exists Books(id integer primary key autoincrement,title text,description text,nbpages integer);";
         sqLiteDatabase.execSQL(myQuery);
    }

    public void openDB()
    {
        this.db = getWritableDatabase();
    }

    public void CloseDB()
    {
        this.db.close();
    }

    public void AddBook(String title,String desc,int nbpages)
    {
        ContentValues cv = new ContentValues();
        cv.put("title",title);
        cv.put("description",desc);
        cv.put(String.valueOf(20),nbpa ges);

        this.db.insert("Books",null,cv);
    }

    public void DeleteBook(int id)
    {
        ContentValues cv = new ContentValues();
        cv.put("id",id);

        this.db.delete("Books",
                "id = ? ",
                new String[]{String.valueOf(id)});
    }

    public void modifyBook(int id,String desc)
    {
        ContentValues cv = new ContentValues();
        cv.put("id",id);
        cv.put("description", desc);

        this.db.update("Books",
                cv,"id = ?",
                new String[]{String.valueOf(id)});

    }

    public ArrayList<Book> getAllBooks()
    {
        ArrayList<Book> bookArrayList = new ArrayList<>();

        Cursor c = this.db.rawQuery("select * from Books;",null);

        int idIndex = c.getColumnIndex("id");
        int titleIndex = c.getColumnIndex("title");
        int descIndex = c.getColumnIndex("description");
        int nbpagesIndex = c.getColumnIndex("nbpages");

        if((c != null) && c.moveToFirst())
        {
            do {
                bookArrayList.add(new Book(c.getInt(idIndex),
                                           c.getString(titleIndex),
                                           c.getString(descIndex),
                                           c.getInt(nbpagesIndex)));

            }while(c.moveToNext());
        }

        
        return bookArrayList;
    }

    public Book getBookWithId(int id)
    {
       Book b = null;

        Cursor c = this.db.rawQuery("select * from Books where id = ?;",new String[]{String.valueOf(id)});

        int idIndex = c.getColumnIndex("id");
        int titleIndex = c.getColumnIndex("title");
        int descIndex = c.getColumnIndex("description");
        int nbpagesIndex = c.getColumnIndex("nbpages");

        if((c != null) && c.moveToFirst())
        {

                b = new Book(c.getInt(idIndex),
                        c.getString(titleIndex),
                        c.getString(descIndex),
                        c.getInt(nbpagesIndex));


        }


        return b;
    }
}
