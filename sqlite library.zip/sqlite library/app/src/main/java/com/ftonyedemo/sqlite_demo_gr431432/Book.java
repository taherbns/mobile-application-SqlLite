package com.ftonyedemo.sqlite_demo_gr431432;

public class Book {

    private int id;
    private String title;
    private String desc;
    private int nbpages;

    public Book(int id, String title, String desc, int nbpages) {
        this.id = id;
        this.title = title;
        this.desc = desc;
        this.nbpages = nbpages;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public int getNbpages() {
        return nbpages;
    }

    public void setNbpages(int nbpages) {
        this.nbpages = nbpages;
    }
}
