package com.ftonyedemo.sqlite_demo_gr431432;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private MyBooksTableDataGateWay gateWay;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.gateWay = new MyBooksTableDataGateWay(this,"mesLivres",null,1);
        this.gateWay.openDB();
     //  this.gateWay.AddBook("vive le java","intro au java",567);
       // gateWay.AddBook("vive le c#","intro au c#",823);
      //  gateWay.DeleteBook(2);
       // gateWay.modifyBook(4,"de Java a Kotlin");

        ArrayList<Book> alb = new ArrayList<>();
        alb = this.gateWay.getAllBooks();
        Book monLivre = this.gateWay.getBookWithId(1);

        this.gateWay.CloseDB();
    }
}